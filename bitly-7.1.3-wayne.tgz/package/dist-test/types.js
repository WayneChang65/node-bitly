"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isBitlyLink = isBitlyLink;
exports.isBitlyErrResponse = isBitlyErrResponse;
/**
 * Type Guards
 */
function isBitlyLink(response) {
    return 'link' in response && 'id' in response && 'long_url' in response;
}
function isBitlyErrResponse(response) {
    return 'message' in response && 'resource' in response;
}
//# sourceMappingURL=types.js.map