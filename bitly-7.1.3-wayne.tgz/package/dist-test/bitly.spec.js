"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
const bitly_1 = require("./bitly");
const types_1 = require("./types");
const lib_1 = require("./lib");
require("../test/bootstrap");
const EXAMPLE_URL = 'https://github.com/tanepiper/node-bitly';
let EXAMPLE_SHORTENED = {
    OLD_STYLE_HASH: '1JtuvXY',
    // Serves as both hash and ID
    URL_HASH: 'bit.ly/1JtuvXY',
    // Full URL
    URL_BITLY: 'http://bit.ly/2hpSRbP'
};
describe('Bitly client', () => {
    let bitly;
    before(() => {
        bitly = new bitly_1.BitlyClient(process.env.BITLY_API_KEY);
    });
    describe('shorten', () => {
        it('should shorten a url', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.shorten(EXAMPLE_URL);
                const isLinkResponse = (0, types_1.isBitlyLink)(data);
                const resultTypePassed = (0, chai_1.expect)(isLinkResponse)
                    .to.equal(true);
                if (!(0, types_1.isBitlyLink)(data)) {
                    return false;
                }
                const idPassed = (0, chai_1.expect)(data)
                    .to.have.property('id')
                    .and.to.match(lib_1.BitlyIdPattern);
                const linkPassed = (0, chai_1.expect)(data)
                    .to.have.property('link')
                    .and.to.be.an('string')
                    .and.to.satisfy((link) => {
                    return link === `http://${data.id}` || link === `https://${data.id}`;
                });
                if ((0, types_1.isBitlyLink)(data)) {
                    EXAMPLE_SHORTENED = {
                        OLD_STYLE_HASH: data.id.replace('bit.ly/', ''),
                        URL_BITLY: data.link,
                        URL_HASH: data.id
                    };
                }
                return idPassed && linkPassed && resultTypePassed;
            }
            catch (error) {
                throw error;
            }
        }));
    });
    describe('should handle invalid requests', () => {
        it('it should throw an error', () => __awaiter(void 0, void 0, void 0, function* () {
            let err;
            try {
                yield bitly.shorten('NOT_REAL_URL');
            }
            catch (error) {
                err = error;
            }
            const isBitlyErr = (0, types_1.isBitlyErrResponse)(err);
            (0, chai_1.expect)(isBitlyErr).to.equal(true);
            return (0, chai_1.expect)(err)
                .to.have.property('resource')
                .and.to.equal('bitlinks');
        }));
    });
    describe('should work with bitly api endpoints with no helper', () => {
        it('should accept any valid bitly url and data object', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.bitlyRequest(`bitlinks/${EXAMPLE_SHORTENED.URL_HASH}/referrers_by_domains`, {}, 'GET');
                return (0, chai_1.expect)(data).to.have.property('referrers_by_domain').that.satisfy((referrer_data) => {
                    return Array.isArray(referrer_data);
                });
            }
            catch (error) {
                throw error;
            }
        }));
    });
    describe('expand', () => {
        it('should expand a url and hash', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.expand(EXAMPLE_SHORTENED.URL_HASH);
                return (0, chai_1.expect)(data)
                    .to.have.property('long_url')
                    .that.is.equal(EXAMPLE_URL);
            }
            catch (error) {
                throw error;
            }
        }));
    });
    describe('clicks', () => {
        it('should get click numbers for url', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.clicks(EXAMPLE_SHORTENED.URL_BITLY);
                return (0, chai_1.expect)(data).to.have.property('link_clicks').that.is.an('array');
            }
            catch (error) {
                throw error;
            }
        }));
        it('should get click numbers for hash', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.clicks(EXAMPLE_SHORTENED.URL_HASH);
                return (0, chai_1.expect)(data).to.have.property('link_clicks').that.is.an('array');
            }
            catch (error) {
                throw error;
            }
        }));
    });
    describe('clicksByDay', () => {
        it('should get click numbers by day for url', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.clicksByDay(EXAMPLE_SHORTENED.URL_BITLY);
                (0, chai_1.expect)(data).to.have.property('unit').that.is.equal('day');
                (0, chai_1.expect)(data).to.have.property('link_clicks').that.is.an('array');
            }
            catch (error) {
                throw error;
            }
        }));
        it('should get click numbers by day for hash', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.clicksByDay(EXAMPLE_SHORTENED.URL_HASH);
                (0, chai_1.expect)(data).to.have.property('unit').that.is.equal('day');
                (0, chai_1.expect)(data).to.have.property('link_clicks').that.is.an('array');
            }
            catch (error) {
                throw error;
            }
        }));
    });
    // This API endpint is currently returning 500 internal errors for the same requests that were previously working
    describe.skip('clicksByMinute', () => {
        it('should get click numbers by minute for url', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.clicksByMinute(EXAMPLE_SHORTENED.URL_BITLY);
                (0, chai_1.expect)(data).to.have.property('unit').that.is.equal('minute');
                (0, chai_1.expect)(data).to.have.property('link_clicks').that.is.an('array');
            }
            catch (error) {
                throw error;
            }
        }));
        it('should get click numbers by minute for hash', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.clicksByMinute(EXAMPLE_SHORTENED.URL_HASH);
                (0, chai_1.expect)(data).to.have.property('unit').that.is.equal('minute');
                (0, chai_1.expect)(data).to.have.property('link_clicks').that.is.an('array');
            }
            catch (error) {
                throw error;
            }
        }));
    });
    describe('info', () => {
        it('should get info for url', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.info(EXAMPLE_SHORTENED.URL_BITLY);
                return (0, chai_1.expect)(data).to.have.property('title');
            }
            catch (error) {
                throw error;
            }
        }));
        it('should get info for hash', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.info(EXAMPLE_SHORTENED.URL_HASH);
                return (0, chai_1.expect)(data).to.have.property('title');
            }
            catch (error) {
                throw error;
            }
        }));
    });
    describe('referrers', () => {
        it('should look up existing bitly url', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.referrers(EXAMPLE_SHORTENED.URL_BITLY);
                return (0, chai_1.expect)(data).to.have.property('facet').that.equals('referrers');
            }
            catch (error) {
                throw error;
            }
        }));
    });
    describe('countries', () => {
        it('should look up metrics by country', () => __awaiter(void 0, void 0, void 0, function* () {
            try {
                const data = yield bitly.countries(EXAMPLE_SHORTENED.URL_BITLY);
                return (0, chai_1.expect)(data).to.have.property('facet').that.equals('countries');
            }
            catch (error) {
                throw error;
            }
        }));
    });
});
//# sourceMappingURL=bitly.spec.js.map