"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
require("../test/bootstrap");
const lib_1 = require("./lib");
describe('generateUrl', () => {
    it('should return a default url', () => {
        const result = (0, lib_1.generateUrl)('foo');
        (0, chai_1.expect)(result)
            .to.have.property('href')
            .and.to.equal('https://api-ssl.bitly.com/v4/foo');
    });
    it('should return a custom url', () => {
        const result = (0, lib_1.generateUrl)('foo', null, {
            apiUrl: 'api-ssl.myhost.com',
            apiVersion: 'v4',
        });
        (0, chai_1.expect)(result)
            .to.have.property('href')
            .and.to.equal('https://api-ssl.myhost.com/v4/foo');
    });
});
describe('sortUrlsAndHash', () => {
    it('takes urls and hashes and appends them correctly', () => {
        const { shortUrl, hash } = (0, lib_1.sortUrlsAndHash)(['http://example.com', '1KjIwXl']);
        (0, chai_1.expect)(shortUrl).to.have.lengthOf(1);
        (0, chai_1.expect)(hash).to.have.lengthOf(1);
    });
});
//# sourceMappingURL=lib.spec.js.map